import 'package:aula09_bancodados/ui/pages/home_page.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MaterialApp(
    title: 'Cadastros',
    home: HomePage(),
    debugShowCheckedModeBanner: false,
  ));
}