package com.example.aula09_bancodados

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
